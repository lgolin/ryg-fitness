# Files to push to `lgolin/ryg-fitness`

Copy these files into the repo, then commit + push to `main`. GitHub Pages will auto-deploy.

| File | Action | Where it goes |
|---|---|---|
| `index.html` | **Replace** existing | repo root |
| `README.md` | **Replace** existing | repo root |
| `favicon.svg` | **New** | repo root |
| `og-image.png` | **New** (or replace if you re-ran) | repo root |
| `src/website-v4-app.jsx` | **Replace** existing | `src/` |
| `src/website-v4-sections-1.jsx` | **Replace** existing | `src/` |
| `src/website-v4-sections-2.jsx` | **Replace** existing | `src/` |

## Copy changes

The "small classes" language was carrying vibe more than literal size. Switched the whole site to **"friendly fitness for women"** — keeps the warmth without implying class size.

**Note:** Your most recent GitHub state was used as the base, so the following are preserved untouched:
- Course start date ("Monday, 25 May 2026")
- Real OpenStreetMap iframe for Find Us
- Static monogram/name placeholder for Janet's portrait
- "Made with love by lgolin" footer attribution
- Your indentation reformatting

Specifically:
- Hero — "Small classes for women" → **"Friendly fitness for women"**
- Hero sub — "A small room of women, moving together" → **"A room of women, moving together"**
- Welcome — "RyG is small classes for women in Tralee" → **"RyG is fitness for women in Tralee"**
- "What we are" bullet — "A small class for women" → **"A friendly room for women"**
- About Janet — "small, friendly, no shouting" → **"friendly, no shouting"**
- FAQ ("Can I come on my own?") — rewritten to: **"Most women do. We're a friendly bunch — you'll know a few names by the end of your first class."**
- Footer — "Small classes for women" → **"Friendly fitness for women"**
- `<title>`, meta description, OG title, Twitter title — all updated
- OG image regenerated with new subtitle

## What changed in `index.html`

Only the `<head>` was touched. Body and script tags are unchanged.

Additions:
- `<link rel="icon" type="image/svg+xml" href="favicon.svg" />` — tab icon
- `<link rel="apple-touch-icon" href="favicon.svg" />` — iOS home-screen icon
- `<meta name="theme-color" content="#EFE8D6" />` — mobile browser chrome matches cream
- `<link rel="canonical" href="https://www.ryg.ie/" />` — SEO canonical URL
- Open Graph block (`og:title`, `og:description`, `og:image`, `og:url`, `og:locale=en_IE`) — Facebook, WhatsApp, LinkedIn, iMessage previews
- Twitter Card block (`twitter:card=summary_large_image`) — Twitter / X previews

## Verifying after deploy

1. Visit `https://www.ryg.ie` — favicon should appear in the browser tab.
2. Paste `https://www.ryg.ie` into a WhatsApp chat or iMessage — preview card with the OG image should appear.
3. For Facebook specifically, run the URL through the [Sharing Debugger](https://developers.facebook.com/tools/debug/) and click "Scrape Again" — Facebook caches old previews for ~24h.

## About the Babel "warning"

The `In-browser Babel transformer` warning in the console is **informational only**. The site works perfectly with it. The only way to silence it is to add a build step (precompile `.jsx` → `.js`), which would break your "no build step" workflow per the README. I'd leave it.

If you do want it gone later, the cleanest path is a tiny GitHub Action that runs Babel on the `src/` folder before deploy — JSX files stay editable in the repo, but visitors load precompiled JS. Happy to set that up if you want.
